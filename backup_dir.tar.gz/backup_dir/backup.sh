#!/bin/bash
ORIGEN=$1
DESTINO=$2
if [[ $1 == "-help" ]]; then
	echo "Uso: ./backup.sh <origen> <destino>"
	echo "Ejemplo: ./backup.sh /www_dir /backup_dir"
	exit 0
fi
if [[ ! -d $ORIGEN ]]; then
	echo "Error: el directorio origen no existe."
	exit 1
fi
if [[ ! -d $DESTINO ]]; then
	echo "Error: el directorio destino no existe."
	exit 1
fi 
FECHA=`date +%Y%m%d_%H%M%S`
ARCHIVO_BACKUP="backup_$FECHA.tar.gz"
tar -czf $DESTINO/$ARCHIVO_BACKUP $ORIGEN 
echo "Backup realizado: $DESTINO/$ARCHIVO_BACKUP"
