
#!/bin/bash

#DEFINICION DE VARIABLES:

ORIGEN=$1
DESTINO=$2

#OPCION DE AYUDA:

if [[ $1 == "-help" ]]; then
	echo "Uso: ./backup.sh <origen> <destino>"
	echo "Ejemplo: ./backup.sh /www_dir /backup_dir"
	exit 0
fi

#VALIDAR CANTIDAD DE ARGUMENTOS:

if [[ $# -ne 2 ]]; then
	echo "Error: se deben ingresar origen y destino"
	exit 1
fi


#VALIDAR DIRECTORIO ORIGEN:


if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: el directorio origen no existe."
	exit 1
fi


#VALIDAR DIRECTORIO DESTINO:


if [[ ! -d "$DESTINO" ]]; then
	echo "Error: el directorio destino no existe."
	exit 1
fi 


#GENERAR FECHA EN FORMATO ANSI:

FECHA=$(date +%Y%m%d) 

#GENERAR NOMBRE DE BACKUP:

#obtiene el nombre del directorio sin la ruta completa
NOMBRE=$(basename "$ORIGEN")  

#construye el nombre final del archivo
ARCHIVO_BACKUP="${NOMBRE}_bkp_$FECHA.tar.gz"


#CREAR BACKUP:

if tar -czf $DESTINO/$ARCHIVO_BACKUP $ORIGEN; then
	echo "Backup realizado: $DESTINO/$ARCHIVO_BACKUP"
else
	echo "Error al finalizar backup"
fi



